﻿param (
    [Parameter(Mandatory)]
    [string]$RegionCode,
    [Parameter(Mandatory)]
    [string]$RuleNamePrefix
)

$regionMap = @{
    "us-east-2"     = "US East (Ohio)"
    "us-east-1"     = "US East (N. Virginia)"
    "us-west-1"     = "US West (N. California)"
    "us-west-2"     = "US West (Oregon)"
    "ap-south-1"    = "Asia Pacific (Mumbai)"
    "ap-northeast-2"= "Asia Pacific (Seoul)"
    "ap-southeast-1"= "Asia Pacific (Singapore)"
    "ap-southeast-2"= "Asia Pacific (Sydney)"
    "ap-northeast-1"= "Asia Pacific (Tokyo)"
    "ca-central-1"  = "Canada (Central)"
    "eu-central-1"  = "Europe (Frankfurt)"
    "eu-west-1"     = "Europe (Ireland)"
    "eu-west-2"     = "Europe (London)"
    "sa-east-1"     = "South America (São Paulo)"
}

if (-not $regionMap.ContainsKey($RegionCode)) {
    Write-Host "Invalid region code."
    Read-Host "Press Enter to close this window."
    exit
}

$pattern = "$RuleNamePrefix - $RegionCode*"
$rules = Get-NetFirewallRule | Where-Object { $_.DisplayName -like $pattern }
$totalRemoved = 0

Write-Host "Removing rules for $RegionCode ($($regionMap[$RegionCode]))..."

foreach ($rule in $rules) {
    Remove-NetFirewallRule -Name $rule.Name
    Write-Host "Removed: $($rule.DisplayName)"
    $totalRemoved++
}

Write-Host "`n$totalRemoved rules removed for $RegionCode."
Write-Host "Press Enter to close this window."
Read-Host
exit
