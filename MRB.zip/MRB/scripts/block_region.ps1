﻿param (
    [Parameter(Mandatory)]
    [string]$RegionCode,
    [Parameter(Mandatory)]
    [string]$GameExePath,
    [Parameter(Mandatory)]
    [string]$RuleNamePrefix,
    [Parameter(Mandatory)]
    [string]$RegionCodesDir
)

$regionFile = Join-Path $RegionCodesDir "$RegionCode.txt"
if (-not (Test-Path $regionFile)) {
    Write-Host "No IP list file found for region $RegionCode at $regionFile"
    Read-Host "Press Enter to close this window."
    exit
}

$ipRanges = Get-Content $regionFile
$newRulesCreated = 0

foreach ($ipRange in $ipRanges) {
    $ruleName = "$RuleNamePrefix - $RegionCode - $ipRange"
    if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule `
            -DisplayName $ruleName `
            -Direction Outbound `
            -Action Block `
            -Program $GameExePath `
            -RemoteAddress $ipRange `
            -Profile Any `
            -Enabled True `
            -Description "Blocks Dead by Daylight from region $RegionCode"
        $newRulesCreated++
        Write-Host "Blocked: $RegionCode ($ipRange)"
    }
}

Write-Host "`n$newRulesCreated rules have been added. Press Enter to close this window."
Read-Host
exit
