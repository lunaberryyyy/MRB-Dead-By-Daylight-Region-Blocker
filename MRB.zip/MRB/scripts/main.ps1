# Paths setup
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$RegionCodesDir = Join-Path $ScriptDir "..\Region Codes"

$gameExePath = "E:\SteamLibrary\steamapps\common\Dead by Daylight\DeadByDaylight\Binaries\Win64\DeadByDaylight-Win64-Shipping.exe"
$ruleNamePrefix = "MRB_DBD"

$regionMap = @{
    "us-east-2"     = "US East (Ohio)"
    "us-east-1"     = "US East (N. Virginia)"
    "us-west-1"     = "US West (N. California)"
    "us-west-2"     = "US West (Oregon)"
    "ap-south-1"    = "Asia Pacific (Mumbai)"
    "ap-northeast-2"= "Asia Pacific (Seoul)"
    "ap-southeast-1"= "Asia Pacific (Singapore)"
    "ap-southeast-2"= "Asia Pacific (Sydney)"
    "ap-northeast-1"= "Asia Pacific (Tokyo)"
    "ca-central-1"  = "Canada (Central)"
    "eu-central-1"  = "Europe (Frankfurt)"
    "eu-west-1"     = "Europe (Ireland)"
    "eu-west-2"     = "Europe (London)"
    "sa-east-1"     = "South America (S�o Paulo)"
}

$regionPages = @(
    @("us-east-2", "us-east-1", "us-west-1", "us-west-2", "ap-south-1"),
    @("ap-northeast-2", "ap-southeast-1", "ap-southeast-2", "ap-northeast-1", "ca-central-1"),
    @("eu-central-1", "eu-west-1", "eu-west-2", "sa-east-1")
)

function Show-MainMenu {
    while ($true) {
        Clear-Host
        Write-Host "Dead by Daylight AWS Region Firewall Tool`n"
        Write-Host "1 - Update IP Ranges"
        Write-Host "2 - Block Server Regions"
        Write-Host "3 - Remove Server Region Blocks (ALL)"
        Write-Host "4 - Remove Server Region Blocks (SELECTED)"
        Write-Host "0 - Cancel"
        $choice = Read-Host "`nEnter selection"
        switch ($choice) {
            "1" { Update-IpRanges }
            "2" { Block-Regions }
            "3" { Remove-Rules }
            "4" { Remove-Rules-Selected }
            "0" { exit }
        }
    }
}

function Update-IpRanges {
    Clear-Host
    Write-Host "Updating IP Ranges from AWS..."
    $awsIpJsonUrl = "https://ip-ranges.amazonaws.com/ip-ranges.json"

    if (-not (Test-Path $RegionCodesDir)) {
        New-Item -ItemType Directory -Path $RegionCodesDir | Out-Null
    } else {
        Get-ChildItem -Path $RegionCodesDir -Filter *.txt | Remove-Item -Force
    }

    try {
        $ipData = Invoke-RestMethod -Uri $awsIpJsonUrl
        $allRegions = $regionMap.Keys
        foreach ($region in $allRegions) {
            $prefixes = $ipData.prefixes | Where-Object { $_.region -eq $region }
            $ipList = $prefixes | ForEach-Object { $_.ip_prefix }
            $filePath = Join-Path -Path $RegionCodesDir -ChildPath "$region.txt"
            $ipList | Set-Content -Path $filePath
            Write-Host "Saved $($ipList.Count) IPs for $region to $filePath"
        }
        Write-Host "`nUpdate complete. Press Enter to return to main menu."
        Read-Host
    } catch {
        Write-Host "Failed to update IP ranges. Error: $_"
        Read-Host
    }
}

function Block-Regions {
    $currentPage = 0
    while ($true) {
        Clear-Host
        Write-Host "Block Server Regions - Page $($currentPage + 1)`n"
        $regions = $regionPages[$currentPage]
        for ($i = 0; $i -lt $regions.Count; $i++) {
            $region = $regions[$i]
            $name = $regionMap[$region]
            Write-Host "$($i + 1) - $region ($name)"
        }
        Write-Host "8 - Previous Page"
        Write-Host "9 - Next Page"
        Write-Host "0 - Main Menu"

        $input = Read-Host "`nSelect a region to block (1 digit only)"
        switch ($input) {
            "8" { 
                if ($currentPage -gt 0) {
                    $currentPage--
                } else {
                    Write-Host "You are already on the first page."
                    Start-Sleep -Seconds 1.5
                }
            }
            "9" { $currentPage = ($currentPage + 1) % $regionPages.Count }
            "0" { return }
            default {
                if ($input.Length -eq 1 -and $input -match '^\d$') {
                    $idx = [int]$input
                    if ($idx -in 1..$regions.Count) {
                        $regionCode = $regions[$idx - 1]
                        $regionName = $regionMap[$regionCode]
                        $confirm = Read-Host "Block $regionCode ($regionName)? (Y/N)"
                        if ($confirm -eq "Y") {
                            $blockScript = Join-Path $ScriptDir "block_region.ps1"
                            Start-Process powershell -ArgumentList "-ExecutionPolicy", "Bypass", "-File", "`"$blockScript`"", "`"$regionCode`"", "`"$gameExePath`"", "`"$ruleNamePrefix`"", "`"$RegionCodesDir`""
                            Write-Host "Blocking $regionCode in a new window."
                            Start-Sleep -Seconds 1.5
                        } else {
                            Write-Host "Cancelled."
                            Start-Sleep -Seconds 1
                        }
                    } else {
                        Write-Host "Invalid selection. Please enter a valid option."
                        Start-Sleep -Seconds 1
                    }
                } else {
                    Write-Host "Only one number at a time is allowed. Please try again."
                    Start-Sleep -Seconds 1
                }
            }
        }
    }
}

function Remove-Rules {
    Clear-Host
    Write-Host "This will remove all region block rules starting with '$ruleNamePrefix'."
    $confirm = Read-Host "Are you sure? (Y/N)"
    if ($confirm -ne "Y") {
        Write-Host "Operation cancelled. Press Enter to return."
        Read-Host
        return
    }

    $rules = Get-NetFirewallRule | Where-Object { $_.DisplayName -like "$ruleNamePrefix*" }
    if ($rules.Count -eq 0) {
        Write-Host "No rules found to remove. Press Enter to return."
        Read-Host
        return
    }

    foreach ($rule in $rules) {
        Remove-NetFirewallRule -Name $rule.Name
        Write-Host "Removed: $($rule.DisplayName)"
    }

    Write-Host "`nAll matching rules removed."
    Read-Host "Press Enter to return to main menu."
}

function Remove-Rules-Selected {
    $currentPage = 0
    while ($true) {
        Clear-Host
        Write-Host "Remove Server Region Blocks (SELECTED) - Page $($currentPage + 1)`n"
        $regions = $regionPages[$currentPage]
        for ($i = 0; $i -lt $regions.Count; $i++) {
            $region = $regions[$i]
            $name = $regionMap[$region]
            Write-Host "$($i + 1) - $region ($name)"
        }
        Write-Host "8 - Previous Page"
        Write-Host "9 - Next Page"
        Write-Host "0 - Main Menu"

        $input = Read-Host "`nSelect a region to remove (1 digit only)"
        if ($input -eq "8") {
            if ($currentPage -gt 0) {
                $currentPage--
            } else {
                Write-Host "You are already on the first page."
                Start-Sleep -Seconds 1.5
            }
        } elseif ($input -eq "9") {
            $currentPage = ($currentPage + 1) % $regionPages.Count
        } elseif ($input -eq "0") {
            return
        } elseif ($input.Length -eq 1 -and $input -match '^\d$') {
            $idx = [int]$input
            if ($idx -ge 1 -and $idx -le $regions.Count) {
                $regionCode = $regions[$idx - 1]
                $regionName = $regionMap[$regionCode]
                $confirm = Read-Host "Remove rules for $regionCode ($regionName)? (Y/N)"
                if ($confirm -eq "Y") {
                    $removeScript = Join-Path $ScriptDir "remove_region_single.ps1"
                    Start-Process powershell -ArgumentList "-ExecutionPolicy", "Bypass", "-File", "`"$removeScript`"", "`"$regionCode`"", "`"$ruleNamePrefix`""
                    Write-Host "Removing $regionCode in a new window."
                    Start-Sleep -Seconds 1.5
                } else {
                    Write-Host "Cancelled."
                    Start-Sleep -Seconds 1
                }
            } else {
                Write-Host "Invalid selection. Please enter a valid option."
                Start-Sleep -Seconds 1
            }
        } else {
            Write-Host "Only one number at a time is allowed. Please try again."
            Start-Sleep -Seconds 1
        }
    }
}

Show-MainMenu
